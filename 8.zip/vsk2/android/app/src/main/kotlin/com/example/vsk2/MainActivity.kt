package com.example.vsk2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
